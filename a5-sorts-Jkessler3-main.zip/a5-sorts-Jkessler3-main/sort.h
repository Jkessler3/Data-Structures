#ifndef SORT
#define SORT

#include <chrono>
#include "arrayList.h"

template<class ItemType> 
class Sort { 
protected:
    long long int swaps;
    long long int comparisons;
    std::chrono::milliseconds runTime;     
public: 
    Sort();

    long long int getSwaps();
    long long int getComparisons();
    std::chrono::milliseconds getRunTime();

    virtual void sort(ArrayList<ItemType>&) = 0; 
};

#include "sort.cpp"  
#endif
