template<class ItemType>
QuickSort<ItemType>::QuickSort(){

}

template<class ItemType>
void QuickSort<ItemType>::quickSort(ArrayList<ItemType>& a, int first, int last){
    if( first < last){
        int splitPoint;
        splitPoint = split(a, first, last);

        quickSort(a, first, splitPoint-1);
        quickSort(a, splitPoint + 1, last);
    }

}

template<class ItemType>
int QuickSort<ItemType>::split(ArrayList<ItemType>& a, int first, int last){
    int splitPoint = first;
    ItemType values = a.getEntry(last);
    ItemType temp;
    bool onCorrectSide;

    for(int j = first; j < last; j++){
        this->comparisons++;
        if(a.getEntry(j) < values){
            this->swaps++;
            temp = a.getEntry(j);
            a.replace(j, a.getEntry(splitPoint));
            a.replace(splitPoint, temp);
            splitPoint++;
        }
    }
    this->swaps++;
    temp = a.getEntry(last);
    a.replace(first, a.getEntry(splitPoint));
    a.replace(splitPoint, temp);

    return splitPoint;
}

template<class ItemType>
void QuickSort<ItemType>::sort(ArrayList<ItemType>& a){
    this->swaps = 0;
    this->comparisons = 0;
    
    //grab start time
    auto begin = std::chrono::high_resolution_clock::now();

    quickSort(a, 1, a.getLength());

    //grab end time
    auto end = std::chrono::high_resolution_clock::now();
    this->runTime = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin); //set runTime
}