#ifndef QUICK_SORT
#define QUICK_SORT

#include "sort.h"

template<class ItemType>
class QuickSort : public Sort<ItemType>{
public:
    QuickSort();
    void sort(ArrayList<ItemType>&);
    void quickSort(ArrayList<ItemType>&, int, int);
    int split(ArrayList<ItemType>&, int, int);

};

#include "quickSort.cpp"
#endif