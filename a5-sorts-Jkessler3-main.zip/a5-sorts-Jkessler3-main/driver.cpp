//Author: Jon Kessler
//Date: 10/25/2024
//Purpose: Implementation of HW 5 Sorting with insertion, bubble, and merge sorts. 
//Additionally quick and select sorts were added. Use NUM_RUNS to set the number of runs. 
//Data is exported to files in the data folder.

#include <iostream>
#include <fstream>
using namespace std;

#include "arrayList.h"
#include "selectionSort.h"
#include "bubbleSort.h"
#include "insertionSort.h"
#include "mergeSort.h"
#include "quickSort.h"

#define NUM_RUNS 10

void genRandNum(int, ArrayList<int>&);
bool doSorting(string, Sort<int>*, ArrayList<int>&);

int main(){
    //VARAIBLES
    ArrayList<int> rngList1k;
    ArrayList<int> rngList10k;
    ArrayList<int> rngList100k;

    QuickSort<int> quickSort;
    SelectionSort<int> selectionSort;
    BubbleSort<int> bubbleSort;
    MergeSort<int> mergeSort;
    InsertionSort<int> insertionSort;


    //GENERATE DATA
    genRandNum(100, rngList1k);
    genRandNum(1000, rngList10k);
    genRandNum(10000, rngList100k);


    //RUN SORTS
    //Selection
    doSorting("Select1k", &selectionSort, rngList1k);
    doSorting("Select10k", &selectionSort, rngList10k);
    doSorting("Select100k", &selectionSort, rngList100k);

    //Bubble
    doSorting("Bubble1k", &bubbleSort, rngList1k);
    doSorting("Bubble10k", &bubbleSort, rngList10k);
    doSorting("Bubble100k", &bubbleSort, rngList100k);

    //Merge
    doSorting("Merge1k", &mergeSort, rngList1k);
    doSorting("Merge10k", &mergeSort, rngList10k);
    doSorting("Merge100k", &mergeSort, rngList100k);

    //Insert
    doSorting("Insert1k", &insertionSort, rngList1k);
    doSorting("Insert10k", &insertionSort, rngList10k);
    doSorting("Insert100k", &insertionSort, rngList100k);

    //Quick
    doSorting("Quick1k", &quickSort, rngList1k);
    doSorting("Quick10k", &quickSort, rngList10k);
    doSorting("Quick100k", &quickSort, rngList100k);

    return 0;
}

void genRandNum(int b, ArrayList<int>& a){

    static bool seeded = false;
    int randNum = 0;

    if (!seeded) { // Seed only once
        srand((unsigned) time(NULL));
        seeded = true;
    }

    for(int i = 0; i <= b; i++){

        randNum = rand() % 100;
        a.insert(i, randNum);
    }
}

bool doSorting(string s, Sort<int>* sort, ArrayList<int>& a){
    
    //create and open file
    ofstream outfile;
    outfile.open("data/" + s + ".csv");

     if (!outfile.is_open()) {
        std::cerr << "Error: Could not open file " << s << ".csv for writing." << std::endl;
        return false;  // Exit the function if the file couldn't be opened
    }

    ArrayList<int> temp = a; //create temp array to hold values

    outfile << "Run Time, Comparisons, Swaps\nUnsorted,,\n"; 

    //Unsorted Runs
    for(int i = 0; i < NUM_RUNS; i++){
        temp = a;

        sort->sort(temp);
        //cout << sort->getRunTime().count() << ", " << sort->getComparisons() << ", " << sort->getSwaps() << endl;
        outfile << sort->getRunTime().count() << ", " << sort->getComparisons() << ", " << sort->getSwaps() << endl;
    }

    outfile << "Sorted,,\n";

    //Sorted Runs
    for(int i = 0; i < NUM_RUNS; i++){
        sort->sort(temp);
        outfile << sort->getRunTime().count() << ", " << sort->getComparisons() << ", " << sort->getSwaps() << endl;
    }

    //close file
    outfile.close();
    return true;

}
