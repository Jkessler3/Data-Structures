#ifndef MERGE_SORT
#define MERGE_SORT

#include "sort.h"

template<class ItemType>
class MergeSort : public Sort<ItemType>{
public:
    MergeSort();
    void sort(ArrayList<ItemType>&);
    void mergeSort(ArrayList<ItemType>&, int, int);
    void merge(ArrayList<ItemType>&, int, int, int);

};

#include "mergeSort.cpp"
#endif