#ifndef INSERTION_SORT
#define INSERTION_SORT

#include "sort.h"

template<class ItemType>
class InsertionSort : public Sort<ItemType>{
public:
    InsertionSort();
    void sort(ArrayList<ItemType>&);

};

#include "insertionSort.cpp"
#endif