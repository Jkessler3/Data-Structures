template<class ItemType>
SelectionSort<ItemType>::SelectionSort(){

}

template<class ItemType>
void SelectionSort<ItemType>::sort(ArrayList<ItemType>& a){
    this->swaps = 0;
    this->comparisons = 0;
    
    //grab start time
    auto begin = std::chrono::high_resolution_clock::now();

    int min = 0;
    ItemType temp = 0;

    for(int i = 1; i <= a.getLength(); i++){
        min = i;
        for(int j = i + 1; j <= a.getLength(); j++){
            if(a.getEntry(j) < a.getEntry(min)){
                min = j; 
            }
            this->comparisons++;
        }
        temp = a.getEntry(i);
        a.replace(i, a.getEntry(min));
        a.replace(min, temp);

        this->swaps++;
    }

    //grab end time
    auto end = std::chrono::high_resolution_clock::now();
    this->runTime = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin); //set runTime
}