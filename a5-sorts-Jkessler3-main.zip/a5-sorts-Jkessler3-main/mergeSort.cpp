template<class ItemType>
MergeSort<ItemType>::MergeSort(){

}

template<class ItemType>
void MergeSort<ItemType>::mergeSort(ArrayList<ItemType>& a, int b, int c){
    if( b < c){
        int middle = (b + c) / 2;
        mergeSort(a, b, middle);
        mergeSort(a, middle + 1, c);
        merge(a, b, middle, c);
    }
    
}

template<class ItemType>
void MergeSort<ItemType>::merge(ArrayList<ItemType>& a, int b, int c, int d){
    int first1 = b, last1 = c, first2 = c + 1, last2 = d;
    ArrayList<ItemType> temp = a;
    ItemType alpha, beta;

    int index = first1;
    while(first1 <= last1 && first2 <= last2){
        alpha = temp.getEntry(first1);
        beta = temp.getEntry(first2);
        
        this->comparisons++;
        if(alpha <= beta){
            a.replace(index, alpha);
            first1++;
        }
        else{
            a.replace(index, beta);
            first2++;
        }
        index++;
    }
    while(first1 <= last1){
        alpha = temp.getEntry(first1);
        a.replace(index, alpha);
        first1++;
        index++;
    }
    while(first2 <= last2){
        beta = temp.getEntry(first2);
        a.replace(index, beta);
        first2++;
        index++;
    }
}

template<class ItemType>
void MergeSort<ItemType>::sort(ArrayList<ItemType>& a){
    this->swaps = 0;
    this->comparisons = 0;
    
    //grab start time
    auto begin = std::chrono::high_resolution_clock::now();

    mergeSort(a, 1, a.getLength());

    //grab end time
    auto end = std::chrono::high_resolution_clock::now();
    this->runTime = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin); //set runTime
}