template<class ItemType>
InsertionSort<ItemType>::InsertionSort(){

}

template<class ItemType>
void InsertionSort<ItemType>::sort(ArrayList<ItemType>& a){
    this->swaps = 0;
    this->comparisons = 0;
    
    //grab start time
    auto begin = std::chrono::high_resolution_clock::now();

    for (int i = 2; i < a.getLength(); i++) {
            ItemType temp = a.getEntry(i);
            int j = i - 1;
            while(j > 1 && a.getEntry(j) > a.getEntry(j-1)){
                temp = a.getEntry(j);
                a.replace((j), a.getEntry(j-1));
                a.replace((j-1), temp);

                j--;
                this->swaps++;
                this->comparisons++;
            }
            
            a.replace((j+1), temp);
    }

    //grab end time
    auto end = std::chrono::high_resolution_clock::now();
    this->runTime = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin); //set runTime
}