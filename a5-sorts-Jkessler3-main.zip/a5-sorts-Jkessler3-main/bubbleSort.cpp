template<class ItemType>
BubbleSort<ItemType>::BubbleSort(){

}

template<class ItemType>
void BubbleSort<ItemType>::sort(ArrayList<ItemType>& a){
    this->swaps = 0;
    this->comparisons = 0;
    
    //grab start time
    auto begin = std::chrono::high_resolution_clock::now();

    for(int i = 1; i < a.getLength(); i++){
        for(int j = 1; j < a.getLength() - i; j++){

            this->comparisons++;

            if(a.getEntry(j) > a.getEntry(j+1)){

                //swap
                ItemType b = a.getEntry(j);
                ItemType c = a.getEntry(j + 1);

                a.replace(j, c);
                a.replace(j + 1, b);

                this->swaps++;
            }
        }
    }


    //grab end time
    auto end = std::chrono::high_resolution_clock::now();
    this->runTime = std::chrono::duration_cast<std::chrono::milliseconds>(end - begin); //set runTime

}